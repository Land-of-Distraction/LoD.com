define([], function () {
  return jQuery;
});