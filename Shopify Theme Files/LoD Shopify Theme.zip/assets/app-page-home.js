define([
	"view-home",
	"domReady",
	"jquery"
], function (ViewHome, domReady, $) {
	"use strict";

	// Global requires
	domReady(function(){
		new ViewHome({el: $('.homepage-container')});
	});
});